package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonAdd, buttonSubtract, buttonDivide, buttonMultiply, buttonClean,
            buttonPercent, buttonSquare, buttonSqrt;
    private TextView operation, result;
    private EditText number1, number2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAdd=findViewById(R.id.buttonAdd);
        buttonSubtract=findViewById(R.id.buttonSubtract);
        buttonDivide=findViewById(R.id.buttonDivide);
        buttonMultiply=findViewById(R.id.buttonMultiply);
        buttonClean=findViewById(R.id.buttonClean);

        operation=findViewById(R.id.operation);
        result=findViewById(R.id.result);

        number1=findViewById(R.id.number1);
        number2=findViewById(R.id.number2);

        buttonAdd.setOnClickListener(this);
        buttonSubtract.setOnClickListener(this);
        buttonDivide.setOnClickListener(this);
        buttonMultiply.setOnClickListener(this);
        buttonClean.setOnClickListener(this);

        buttonPercent=findViewById(R.id.buttonPercent);
        buttonSquare=findViewById(R.id.buttonSquare);
        buttonSqrt=findViewById(R.id.buttonSqrt);;

        buttonPercent.setOnClickListener(this);
        buttonSquare.setOnClickListener(this);
        buttonSqrt.setOnClickListener(this);
        }

    @Override
    public void onClick(View v) {
        float num1 = 0, num2 = 0, res = 0;

        String s1 = number1.getText().toString();
        String s2 = number2.getText().toString();
        if (!s1.isEmpty()) num1 = Float.parseFloat(s1);
        if (!s2.isEmpty()) num2 = Float.parseFloat(s2);

        int id = v.getId();
        if (id == R.id.buttonAdd) {
            operation.setText("+");
            res = num1 + num2;
        } else if (id == R.id.buttonSubtract) {
            operation.setText("-");
            res = num1 - num2;
        } else if (id == R.id.buttonDivide) {
            operation.setText("/");
            if (num2 != 0) {
                res = num1 / num2;
            } else {
                result.setText("Деление на 0");
                return;}
        } else if (id == R.id.buttonMultiply) {
            operation.setText("*");
            res = num1 * num2;
        } else if (id == R.id.buttonPercent) {
            operation.setText("%");
            if (num2 != 0) {
                res = num1 % num2; // остаток от деления
            } else {
                result.setText("Ошибка");
                return;}
        } else if (id == R.id.buttonSquare) {
            operation.setText("²");
            res = num1 * num1; // возводим первое число в квадрат
        } else if (id == R.id.buttonSqrt) {
            operation.setText("√");
            if (num1 >= 0) {
                res = (float) Math.sqrt(num1);
            } else {
                result.setText("Ошибка");
                return;}
            } else if (id == R.id.buttonClean) {
                number1.setText("");
                number2.setText("");
                operation.setText("");
                result.setText("");
                return;
            } else {
                return;
            }
            result.setText(String.valueOf(res));
        }
    }